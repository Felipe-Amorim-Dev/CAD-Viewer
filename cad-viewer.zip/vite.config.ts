import { defineConfig } from 'vite';
import dts from 'vite-plugin-dts';

export default defineConfig({
  plugins: [
    dts({
      entryRoot: 'src',
      insertTypesEntry: true
    })
  ],

  build: {
    lib: {  
      entry: new URL( './src/index.ts', import.meta.url ).pathname,
      name: 'CadViewer',
      formats: [
        'es',
        'umd'
      ],

      fileName: (format) => {
        if (format === 'es') {
          return 'cad-viewer.js';
        }

        return 'cad-viewer.umd.cjs';
      }
    },

    sourcemap: true,

    emptyOutDir: true,

    rollupOptions: {
      output: {
        assetFileNames: 'cad-viewer.[ext]'
      }
    }
  }
});